from flask import Flask, render_template, request, redirect
from users import User

app = Flask(__name__)

def connect_to_mysql():
    return connectToMySQL('users_schema')

@app.route("/")
def index():
    return redirect('/users')

@app.route('/users')
def users():
    return render_template("read_all.html", users=User.get_all())

@app.route('/users/new')
def new():
    return render_template("create.html")

@app.route("/users/create", methods=['POST'])
def create():
    if request.method == 'POST':
        try:
            first_name = request.form['first_name']
            last_name = request.form['last_name']
            email = request.form['email']

            new_user_data = {
                'first_name': first_name,
                'last_name': last_name,
                'email': email
            }
            new_user = User(new_user_data)

            new_user_id = new_user.save()

            return redirect(f'/users/{new_user_id}')

        except Exception as e:
            return redirect('/users/new')

    return redirect('/users/new')
    
@app.route('/users/<int:user_id>')
def show(user_id):
    user = User.get_by_id(user_id)
    if user:
        return render_template("show_user.html", user=user)
    else:
        return "User not found", 404

@app.route("/users/<int:user_id>/edit")
def edit_user(user_id):
    user = User.get_one(user_id)
    return render_template("edit_user.html", user=user)


@app.route("/users/<int:user_id>/update", methods=['POST'])
def update_user(user_id):
    if request.method == 'POST':
        try:
            user = User.get_one(user_id)
            first_name = request.form['first_name']
            last_name = request.form['last_name']
            email = request.form['email']

            user_data = {
                'first_name': first_name,
                'last_name': last_name,
                'email': email
            }

            # Update the user data in the database
            user.update(user_data)

            return redirect(f'/users/{user_id}')

        except Exception as e:
            print("Error while updating user:", e)

    return redirect(f'/users/{user_id}/edit')

@app.route('/users/<int:user_id>/update', methods=['POST'])
def update(user_id):
    user = User.get_by_id(user_id)
    if user:
        user.first_name = request.form['first_name']
        user.last_name = request.form['last_name']
        user.email = request.form['email']
        user.save()
        return redirect(f'/users/{user.id}')
    else:
        return "User not found", 404

@app.route('/users/<int:user_id>/delete')
def delete(user_id):
    user = User.get_by_id(user_id)
    if user:
        user.delete()
        return redirect('/users')
    else:
        return "User not found", 404

if __name__ == "__main__":
    app.run(debug=True, host="localhost", port=8000)
