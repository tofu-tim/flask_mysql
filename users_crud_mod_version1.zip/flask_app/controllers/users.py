from flask_app.config.mysqlconnection import connectToMySQL

class User:
    def __init__(self, data):
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
    
    @classmethod
    def get_all(cls):
        query = "SELECT * FROM users;"
        try:
            results = connectToMySQL('users_schema').query_db(query)
            users = [cls(row) for row in results]
            return users
        except Exception as e:
            print("Error while fetching users:", e)
            return []
    
    @classmethod
    def save(cls, data):
        query = "INSERT INTO users (first_name, last_name, email) VALUES (%s, %s, %s);"
        try:
            conn = connectToMySQL('users_schema')
            result = conn.query_db(query, (data['first_name'], data['last_name'], data['email']))
            conn.connection.commit()
            return result
        except Exception as e:
            print("Error while saving user:", e)
            return False
