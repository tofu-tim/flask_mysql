from flask import Flask, render_template, request, redirect, url_for
import pymysql.cursors

app = Flask(__name__)

mysql_config = {
    "host": "localhost",
    "user": "root",
    "password": "root",
    "db": "users_schema",
    "charset": "utf8mb4",
    "cursorclass": pymysql.cursors.DictCursor,
}

def connect_to_mysql():
    return pymysql.connect(**users_schema)

@app.route("/")
def read_all_users():
    try:
        connection = connect_to_mysql()
        with connection.cursor() as cursor:
            # Fetch all users from the database
            sql = "SELECT * FROM users"
            cursor.execute(sql)
            users = cursor.fetchall()
    except Exception as e:
        print("Error while fetching users:", e)
        users = []

    return render_template("read_all.html", users=users)

@app.route("/create", methods=["GET", "POST"])
def create_user():
    if request.method == "POST":
        first_name = request.form["first_name"]
        last_name = request.form["last_name"]
        email = request.form["email"]

        try:
            connection = connect_to_mysql()
            with connection.cursor() as cursor:
                # Insert the new user into the database
                sql = "INSERT INTO users (first_name, last_name, email) VALUES (%s, %s, %s)"
                cursor.execute(sql, (first_name, last_name, email))
                connection.commit()
        except Exception as e:
            print("Error while inserting user:", e)

        return redirect(url_for("read_all_users"))
    else:
        return render_template("create.html")


if __name__ == "__main__":
    app.run(debug=True, host="localhost", port=8000)
