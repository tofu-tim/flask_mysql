from flask import Flask, render_template, request, redirect

app = Flask(__name__)

def connect_to_mysql():
    return pymysql.connect(**users_schema)

@app.route("/")
def read_all_users():
    all_users = Users.get_all()
    print(all_users)
    return render_template("read_all.html", all_users=User.getall())


@app.route("/create")
def create():
    return render_template("create.html")


if __name__ == "__main__":
    app.run(debug=True, host="localhost", port=8000)
